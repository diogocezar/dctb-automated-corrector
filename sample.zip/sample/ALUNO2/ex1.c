#include <stdio.h>

int main(){
	int x=0;
	while(x < 10){
		printf("%d\n", x);
		x++;
	}
	return 0;
}