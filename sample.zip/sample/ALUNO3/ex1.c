#include <stdio.h>

int main(){
	int cont=0;
	do{
		printf("%d\n", cont);
		cont++;
	}while(cont < 10);
	return 0;
}