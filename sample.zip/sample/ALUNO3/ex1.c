#include <stdio.h>

int main(){
	int cont=4;
	do{
		printf("%d\n", cont);
		cont++;
	}while(cont < 16);
	return 0;
}